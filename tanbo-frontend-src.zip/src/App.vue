<template>
  <div v-if="auth.checking" class="boot">正在连接服务器…</div>

  <Login v-else-if="!auth.user" />

  <div v-else class="shell">
    <aside class="sidebar">
      <div class="brand">
        <div class="brand-mark">串</div>
        <div class="brand-text">
          <b>小摊经营台账</b>
          <span>BAOCAI · TANBO</span>
        </div>
      </div>

      <nav class="nav">
        <button
          v-for="t in tabs"
          :key="t.key"
          class="nav-item"
          :class="{ active: current === t.key }"
          @click="current = t.key"
        >
          <i class="nav-dot"></i>{{ t.label }}
        </button>
      </nav>

      <div class="sidebar-foot">
        <div class="who">{{ auth.user }}</div>
        <button class="logout-btn" @click="handleLogout">退出登录</button>
      </div>
    </aside>

    <main class="main">
      <div v-if="store.error" class="notice">{{ store.error }}</div>
      <component :is="currentView" />
    </main>

    <div v-if="store.toast" class="toast">{{ store.toast }}</div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { store, auth, reload, checkAuth, doLogout } from './store'
import Login from './Login.vue'
import Dashboard from './views/Dashboard.vue'
import Batches from './views/Batches.vue'
import Strands from './views/Strands.vue'
import Sales from './views/Sales.vue'
import Losses from './views/Losses.vue'
import Reports from './views/Reports.vue'

const tabs = [
  { key: 'dashboard', label: '经营仪表盘' },
  { key: 'batches', label: '进货台账' },
  { key: 'strands', label: '剥叶穿串' },
  { key: 'sales', label: '销售记账' },
  { key: 'losses', label: '损耗报损' },
  { key: 'reports', label: '利润报表' }
]

const views = {
  dashboard: Dashboard,
  batches: Batches,
  strands: Strands,
  sales: Sales,
  losses: Losses,
  reports: Reports
}

const current = ref('dashboard')
const currentView = computed(() => views[current.value] || Dashboard)

async function handleLogout() {
  await doLogout()
  current.value = 'dashboard'
}

onMounted(async () => {
  await checkAuth()
  if (auth.user) await reload()
})
</script>
